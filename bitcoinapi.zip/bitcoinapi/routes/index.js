var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
const bitcore = require('bsv');
const datapay = require('datapay');
var querystring = require('querystring');
var bchaddr = require('bchaddrjs');
var url = require('url');
var isLegacyAddress = bchaddr.isLegacyAddress;
var toLegacyAddress = bchaddr.toLegacyAddress;

var EmojiData = require('emoji-data');
var Filter = require('bad-words'),
    filter = new Filter();

var last_message;
const PROFANITY_FILTER_LEVEL_DEFAULT = 1;
	
var key_cycle = 0;
var key_array_size = 100;
var key_array = new Array();
var seed = "put your secret phrase here";
for(var counter = 0; counter < key_array_size; counter++) {
	var value = new Buffer(seed + counter.toString());
	var hash = bitcore.crypto.Hash.sha256(value);
	var bn = bitcore.crypto.BN.fromBuffer(hash);
    var private_key = new bitcore.PrivateKey(bn);
	var address = private_key.toAddress();
	key_array.push([address, private_key]);
}

// RPC
var rpc_server = "https://127.0.0.1:8332";
var rpc_server_2 = "https://127.0.0.1:8332";
//var rpc_server_2 = "https://bchsvexplorer.com";

// API WALLET
const api_wallet = "17HTwz6MnLoFCHad3M4Z8dC9XZAHMW4YPm"; // <-- REPLACE WITH YOUR MAIN WALLET

function urldecode(url) {
  return decodeURIComponent(url.replace(/\+/g, ' '));
}

function process_request(req, res, next) {
	var time_window = 1;
	var MAX_OP_RETURN_SIZE = 1000000000000;

	var profanity_filter = false;
	var queryData = url.parse(req.url, true).query;

	if(!queryData.timestamp && !queryData.data) {
		res.end();
		return;
	}
	
	var developer_tokens = "";
	
	// OPEN DEVELOPER TOKEN
	developer_tokens = developer_tokens + "JRRTOKEN";
	
	if(developer_tokens.indexOf(queryData.timestamp) != -1) {
		queryData.timestamp = parseInt(Math.floor(new Date() / 1000));
	}
	else {
		queryData.timestamp = parseInt(queryData.timestamp);
	}

	var public_key = null;
	var user_message = queryData.data;

	// For IP Logging
	//console.log("REQUEST-BY|" + req.connection.remoteAddress + "|XF|" + req.headers['x-forwarded-for']);
	
	/*
	// To disable sending coins out of API keys
	if(queryData.pubkey) {
		res.write("WALLET_CONTROLLER_DISABLED");
		res.end();
		return;
	}
	*/
	
	if(!queryData.timestamp) {
		console.log("BAD_REQUEST:" + req.connection.remoteAddress + ": XF: " + req.headers['x-forwarded-for']);
		res.write("MALFORMED_REQUEST");
		res.end();
			return;
	} else if ((Math.floor(new Date() / 1000) - queryData.timestamp) > time_window) {
		console.log("EXPIRED_TIMESTAMP by: " + (Math.floor(new Date() / 1000) - parseInt(queryData.timestamp)) + " seconds.");
		res.write("EXPIRED_TIMESTAMP");
		res.end();
			return;
	}

	if(queryData.output) {
		if(isLegacyAddress(queryData.output)) {
			public_key = queryData.output;
		}
		else {
			res.write("INVALID_PUBLIC_KEY");
			return_early = true;
			res.end();
			return;
		}
	}

	// Profanity
	if(queryData.filter == PROFANITY_FILTER_LEVEL_DEFAULT) {
		user_message = filter.clean(user_message);
	}
	
	// This duplicate check DOES NOT WORK! Needs to be debugged/fixed.
	if(last_message == user_message) {
		res.write("ERROR_DUPLICATE_OP_RETURN");
		res.end();
		return;
	}
	else {
		last_message == user_message;
	}

	if(user_message.length < 1 || user_message.length > MAX_OP_RETURN_SIZE) {
			res.write("INVALID_MESSAGE_LENGTH: " + user_message.length);
			res.end();
			return;
	}
	else {

		var fee_satbytes = 3;
		var fee_amount = (user_message.length * fee_satbytes) + (3 * fee_satbytes);
		if(fee_amount < 512)
			fee_amount = 512;
		
		console.log("Message: ");
		console.log(user_message);
		console.log("Sending length " + user_message.length + " with fee of: " + fee_amount + " " + fee_satbytes + " satbytes.");
		
		var this_key = null;
		if(public_key)
			this_key = public_key;
		else
			this_key = api_wallet;

		if(public_key)
			console.log("Sending to outside key: " + public_key);
		
		// Remove coin sends to do prunable op_returns, see below. //
		var tx;
		if(!public_key) {
			if(key_cycle % 2 == 1) {
				tx = {
					data: ["0x", user_message],
					pay: { key: key_array[key_cycle][1], fee: fee_amount , to: [{
					  address: api_wallet,
					  value: 1000 // Remove coin sends to do prunable op_returns //
					}] }
				};
			}
			else {
				tx = {
					data: ["0x", user_message],
					pay: { key: key_array[key_cycle][1], fee: fee_amount , to: [{
					  address: api_wallet,
					  value: 1000 // Remove coin sends to do prunable op_returns //
					}] }
				};
			}
		}
		else {
			if(key_cycle % 2 == 1) {
				tx = {
					data: ["0x", user_message],
					pay: { key: key_array[key_cycle][1], fee: fee_amount , to: [{
					  address: public_key,
					  value: 1000 // Remove coin sends to do prunable op_returns //
					}] }
				};
			}
			else {
				tx = {
					data: ["0x", user_message],
					pay: { key: key_array[key_cycle][1], fee: fee_amount , to: [{
					  address: public_key,
					  value: 1000 // Remove coin sends to do prunable op_returns //
					}] }
				};
			}
		}

		var loop_val = 1;
		for(var i = 0; i < loop_val; i++) {
			datapay.send(tx, function(err, result) {
				if(result) {
					key_cycle++;
					if(key_cycle == key_array_size || key_cycle > key_array_size)
						key_cycle = 0;
					if(loop_val == 1) {
						console.log("SUCCESS|" + result);
						res.write("SUCCESS|" + result);	
						res.end();
					}
					else
						console.log("SUCCESS|" + result);
				}
				else {
					key_cycle++;
					if(key_cycle == key_array_size || key_cycle > key_array_size)
						key_cycle = 0;
					if(loop_val == 1) {
						console.log("ERROR|" + err);
						res.write("RPC_ERROR|" + err);
						res.end();
					}
					else
						console.log("ERROR|" + err);
				}
			});
		}
	}
}

/* POST home page. */
router.post('/', function(req, res, next) {
	process_request(req, res, next);
	return;
});

/* GET home page. */
router.get('/', function(req, res, next) {
	process_request(req, res, next);
	return;
});

module.exports = router;
